describe('Example Test', () => {
    it('Adds two and two together', () => {
        expect(2 + 2).toBe(4);
    });
});
