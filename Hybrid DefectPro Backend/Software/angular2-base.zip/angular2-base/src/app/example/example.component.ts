import { Component } from '@angular/core';

@Component({
    selector: 'example',
    templateUrl: 'app/example/example.component.html'
})
export class ExampleComponent { }

