import { Component } from '@angular/core';

@Component({
    selector: 'about',
    templateUrl: 'app/about/about.component.html'
})
export class AboutComponent { }

