export class Cat {
  _id?: string;
  name?: string;
  weight?: number;
  age?: number;
}
