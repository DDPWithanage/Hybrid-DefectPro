# Server template

Put your server templates in this folder
