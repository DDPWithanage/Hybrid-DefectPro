Files in this folder will be copied to Android native resources during build.
