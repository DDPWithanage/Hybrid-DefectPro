# Angular recipes

- [To be replaced by the first recipe :)](TODO)

## Contributing

Do you have useful code recipes based on this project that you would like to share?
Here's how you can contribute your recipe to the list.

1. [Fork this repository](https://github.com/ngx-rocket/generator-ngx-rocket/fork)
1. Create a new branch for your recipe
1. Create a new markdown file with your recipe name in the `recipes` folder
1. Add a link to your recipe to the [recipes/README.md](recipes/README.md)
1. Commit and push your changes, following the [Conventional Commits](https://www.conventionalcommits.org) format (ie: `docs(recipes): add <RECIPE NAME>`)
1. Submit a pull request
