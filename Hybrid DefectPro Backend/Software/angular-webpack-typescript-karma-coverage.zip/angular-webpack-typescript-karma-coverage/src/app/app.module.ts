import {} from '../transformer';

angular.module('app', ['app.transformer']);