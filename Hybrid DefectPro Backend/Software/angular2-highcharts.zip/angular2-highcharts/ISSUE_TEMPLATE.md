<!--

!!! PLEASE READ BEFORE POSTING AN ISSUE !!!

- Use StackOverflow for questions tagged with angular2-highcharts tag.
- Don't post here Highcharts specific issues. Use official repo instead https://github.com/highcharts/highcharts/issues.
- Read the readme. Probably your issue is not an issue at all.
- Make sure you plugged all the appropriate highcharts modules you need because this causes most of "doesn't work" issues.
- If it is possible provide simple live demo based on one of the readme ones which describing you problem.

-->
