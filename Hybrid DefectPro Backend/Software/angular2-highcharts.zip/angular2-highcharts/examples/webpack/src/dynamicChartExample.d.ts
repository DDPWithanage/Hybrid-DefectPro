export declare class DynamicChartExample {
    constructor();
    chart: any;
    options: any;
    saveInstance(chartInstance: any): void;
    addPoint(): void;
}
