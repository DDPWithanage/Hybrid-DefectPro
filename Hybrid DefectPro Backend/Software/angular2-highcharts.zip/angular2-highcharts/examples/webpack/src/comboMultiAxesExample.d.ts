export declare class ComboMultiAxesExample {
    constructor();
    options: Object;
}
