export declare class HighchartsModuleExample {
    constructor();
    options: Object;
}
