export declare class ChartEventsExample {
    constructor();
    options: Object;
    onChartSelection(e: any): void;
    onSeriesMouseOver(e: any): void;
    onPointSelect(e: any): void;
}
