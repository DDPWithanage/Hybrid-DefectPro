import { Jsonp } from '../../../node_modules/@angular/http';
export declare class StockChartExample {
    constructor(jsonp: Jsonp);
    options: Object;
}
