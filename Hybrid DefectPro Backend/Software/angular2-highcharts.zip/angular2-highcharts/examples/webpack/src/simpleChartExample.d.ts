export declare class SimpleChartExample {
    constructor();
    options: Object;
}
