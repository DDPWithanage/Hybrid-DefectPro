import { BlogService } from './blog.service';

export const services = [BlogService];

export * from './blog.service';
