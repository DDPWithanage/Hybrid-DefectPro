export const directives = [];
