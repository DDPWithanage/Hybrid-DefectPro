import { AppCommonGuard } from './app-common.guard';

export const guards = [AppCommonGuard];

export * from './app-common.guard';
