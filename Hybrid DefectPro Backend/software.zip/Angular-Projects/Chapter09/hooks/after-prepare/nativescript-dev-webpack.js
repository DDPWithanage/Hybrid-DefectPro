module.exports = require("nativescript-dev-webpack/lib/after-prepare.js");
