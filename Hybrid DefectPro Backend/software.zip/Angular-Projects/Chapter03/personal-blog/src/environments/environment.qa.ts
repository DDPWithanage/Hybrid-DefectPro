export const environment = {
  production: true,
  WORDPRESS_REST_URL: 'http://demo7831153.mockable.io/'
};
