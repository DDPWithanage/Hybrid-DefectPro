export const environment = {
  production: true,
  WORDPRESS_REST_URL: 'https://demo8034777.mockable.io/',
  baseHref: '/production/',
  url: 'https://upeuaw788l.execute-api.eu-central-1.amazonaws.com/production',
  seo: {
    description: 'I write my findings in this blog',
    title: 'My Personal Blog',
    author: 'My Name'
  }
};
